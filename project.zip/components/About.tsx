import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import {
  Code2,
  Database,
  Brain,
  Sparkles,
  Server,
  Globe,
  Edit,
} from "lucide-react";
import { motion } from "motion/react";

interface AboutProps {
  isAdmin?: boolean;
  onEdit?: () => void;
}

export function About({ isAdmin, onEdit }: AboutProps) {
  const skills = [
    { name: "React", icon: Code2 },
    { name: "TypeScript", icon: Code2 },
    { name: "Node.js", icon: Server },
    { name: "Python", icon: Code2 },
    { name: "TensorFlow", icon: Brain },
    { name: "PyTorch", icon: Brain },
    { name: "SQL", icon: Database },
    { name: "MongoDB", icon: Database },
    { name: "Next.js", icon: Globe },
    { name: "Tailwind CSS", icon: Sparkles },
    { name: "Docker", icon: Server },
    { name: "AWS", icon: Globe },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Admin Edit Button */}
        {isAdmin && (
          <div className="flex justify-end mb-4">
            <Button onClick={onEdit} variant="outline" size="sm">
              <Edit className="w-4 h-4 mr-2" />
              Edit About
            </Button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Bio Section */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-gray-900 mb-6">About Me</h2>
            <div className="space-y-4 text-gray-600">
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                I'm a passionate full-stack developer and data scientist with a focus on
                building innovative solutions that combine cutting-edge technology with
                practical applications.
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
              >
                With expertise in both frontend and backend development, as well as machine
                learning and AI, I bring a unique perspective to every project. I love
                working on challenging problems that push the boundaries of what's possible.
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
              >
                When I'm not coding, you can find me exploring new technologies, contributing
                to open-source projects, or sharing knowledge with the developer community.
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 }}
              >
                I'm always open to new opportunities and collaborations. Feel free to reach
                out if you'd like to work together!
              </motion.p>
            </div>
          </motion.div>

          {/* Skills Section */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-gray-900 mb-6">Skills & Technologies</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {skills.map((skill, index) => {
                const Icon = skill.icon;
                return (
                  <motion.div
                    key={skill.name}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ scale: 1.05 }}
                    className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <Icon className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">{skill.name}</span>
                  </motion.div>
                );
              })}
            </div>

            {/* Additional Badges */}
            <div className="mt-8">
              <h4 className="text-gray-700 mb-4">Certifications & Achievements</h4>
              <div className="flex flex-wrap gap-2">
                <Badge variant="default">AWS Certified</Badge>
                <Badge variant="default">Google Cloud</Badge>
                <Badge variant="default">GitHub Star</Badge>
                <Badge variant="default">Kaggle Expert</Badge>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
