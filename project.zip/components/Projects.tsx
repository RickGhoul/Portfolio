import { ProjectCard, Project } from "./ProjectCard";
import { Button } from "./ui/button";
import { Plus } from "lucide-react";
import { motion } from "motion/react";

interface ProjectsProps {
  projects: Project[];
  isAdmin?: boolean;
  onAddProject?: () => void;
  onEditProject?: (project: Project) => void;
  onDeleteProject?: (projectId: string) => void;
}

export function Projects({
  projects,
  isAdmin,
  onAddProject,
  onEditProject,
  onDeleteProject,
}: ProjectsProps) {
  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-gray-900 mb-4">My Projects</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            A collection of projects showcasing my skills in development, data science, and AI.
            Each project includes links to the code, notebooks, and additional resources.
          </p>

          {/* Admin Add Button */}
          {isAdmin && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-6"
            >
              <Button onClick={onAddProject} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add New Project
              </Button>
            </motion.div>
          )}
        </motion.div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              isAdmin={isAdmin}
              onEdit={onEditProject}
              onDelete={onDeleteProject}
            />
          ))}
        </div>

        {/* Empty State */}
        {projects.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No projects yet. {isAdmin && "Add your first project!"}</p>
          </div>
        )}
      </div>
    </section>
  );
}
