import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Middleware
app.use("*", cors());
app.use("*", logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
);

// Sign up route - Only allows ONE owner account
app.post("/make-server-e4cfbb59/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }

    // Check if an owner account already exists
    const existingOwner = await kv.get("owner_account_created");
    
    if (existingOwner === "true") {
      return c.json(
        { error: "Owner account already exists. Only one owner account is allowed." },
        403
      );
    }

    // Create the owner account
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role: "owner" },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true,
    });

    if (error) {
      console.error("Error creating owner account:", error);
      return c.json({ error: error.message }, 400);
    }

    // Mark that an owner account has been created
    await kv.set("owner_account_created", "true");
    await kv.set("owner_user_id", data.user.id);

    return c.json({
      success: true,
      message: "Owner account created successfully",
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata.name,
      },
    });
  } catch (err: any) {
    console.error("Signup error:", err);
    return c.json({ error: err.message || "Internal server error" }, 500);
  }
});

// Verify user is the owner
app.get("/make-server-e4cfbb59/verify-owner", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    if (!accessToken) {
      return c.json({ error: "No access token provided" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      return c.json({ error: "Invalid token" }, 401);
    }

    const ownerId = await kv.get("owner_user_id");

    if (user.id !== ownerId) {
      return c.json({ error: "Not authorized as owner" }, 403);
    }

    return c.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata.name,
        role: user.user_metadata.role,
      },
    });
  } catch (err: any) {
    console.error("Verify owner error:", err);
    return c.json({ error: err.message || "Internal server error" }, 500);
  }
});

// Get all projects
app.get("/make-server-e4cfbb59/projects", async (c) => {
  try {
    const projects = await kv.getByPrefix("project_");
    return c.json({ projects });
  } catch (err: any) {
    console.error("Get projects error:", err);
    return c.json({ error: err.message || "Internal server error" }, 500);
  }
});

// Add/Update project (owner only)
app.post("/make-server-e4cfbb59/projects", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    if (!accessToken) {
      return c.json({ error: "No access token provided" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      return c.json({ error: "Invalid token" }, 401);
    }

    const ownerId = await kv.get("owner_user_id");

    if (user.id !== ownerId) {
      return c.json({ error: "Not authorized" }, 403);
    }

    const project = await c.req.json();

    if (!project.id) {
      project.id = crypto.randomUUID();
    }

    await kv.set(`project_${project.id}`, JSON.stringify(project));

    return c.json({ success: true, project });
  } catch (err: any) {
    console.error("Add/update project error:", err);
    return c.json({ error: err.message || "Internal server error" }, 500);
  }
});

// Delete project (owner only)
app.delete("/make-server-e4cfbb59/projects/:id", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    if (!accessToken) {
      return c.json({ error: "No access token provided" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      return c.json({ error: "Invalid token" }, 401);
    }

    const ownerId = await kv.get("owner_user_id");

    if (user.id !== ownerId) {
      return c.json({ error: "Not authorized" }, 403);
    }

    const id = c.req.param("id");
    await kv.del(`project_${id}`);

    return c.json({ success: true });
  } catch (err: any) {
    console.error("Delete project error:", err);
    return c.json({ error: err.message || "Internal server error" }, 500);
  }
});

// Get portfolio content (bio, skills, etc.)
app.get("/make-server-e4cfbb59/content", async (c) => {
  try {
    const content = await kv.getByPrefix("content_");
    const contentObj: Record<string, any> = {};
    
    content.forEach((item: any) => {
      const key = item.key.replace("content_", "");
      try {
        contentObj[key] = JSON.parse(item.value);
      } catch {
        contentObj[key] = item.value;
      }
    });

    return c.json({ content: contentObj });
  } catch (err: any) {
    console.error("Get content error:", err);
    return c.json({ error: err.message || "Internal server error" }, 500);
  }
});

// Update portfolio content (owner only)
app.post("/make-server-e4cfbb59/content", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];

    if (!accessToken) {
      return c.json({ error: "No access token provided" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);

    if (error || !user) {
      return c.json({ error: "Invalid token" }, 401);
    }

    const ownerId = await kv.get("owner_user_id");

    if (user.id !== ownerId) {
      return c.json({ error: "Not authorized" }, 403);
    }

    const { key, value } = await c.req.json();

    if (!key) {
      return c.json({ error: "Key is required" }, 400);
    }

    await kv.set(`content_${key}`, typeof value === "string" ? value : JSON.stringify(value));

    return c.json({ success: true });
  } catch (err: any) {
    console.error("Update content error:", err);
    return c.json({ error: err.message || "Internal server error" }, 500);
  }
});

Deno.serve(app.fetch);
