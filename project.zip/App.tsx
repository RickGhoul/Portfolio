import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Projects } from "./components/Projects";
import { About } from "./components/About";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { Auth } from "./components/Auth";
import { Project } from "./components/ProjectCard";
import { projectId, publicAnonKey } from "./utils/supabase/info";
import { createClient } from "@supabase/supabase-js";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    checkSession();
    loadProjects();
  }, []);

  const checkSession = async () => {
    try {
      const supabase = createClient(
        `https://${projectId}.supabase.co`,
        publicAnonKey
      );

      const { data: { session } } = await supabase.auth.getSession();

      if (session?.access_token) {
        setAccessToken(session.access_token);
        setIsAuthenticated(true);
      }
    } catch (err) {
      console.error("Session check error:", err);
    }
  };

  const loadProjects = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-e4cfbb59/projects`,
        {
          headers: {
            Authorization: `Bearer ${publicAnonKey}`,
          },
        }
      );

      const data = await response.json();

      if (data.projects) {
        const parsedProjects = data.projects.map((item: any) => JSON.parse(item.value));
        setProjects(parsedProjects);
      }
    } catch (err) {
      console.error("Error loading projects:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAuthSuccess = (token: string) => {
    setAccessToken(token);
    setIsAuthenticated(true);
    setShowAuth(false);
    loadProjects();
  };

  const handleSignOut = async () => {
    try {
      const supabase = createClient(
        `https://${projectId}.supabase.co`,
        publicAnonKey
      );

      await supabase.auth.signOut();
      setIsAuthenticated(false);
      setAccessToken(null);
    } catch (err) {
      console.error("Sign out error:", err);
    }
  };

  const handleAddProject = () => {
    alert("Add Project modal would open here");
    // This would open a modal/form to add a new project
  };

  const handleEditProject = (project: Project) => {
    alert(`Edit Project: ${project.title}`);
    // This would open a modal/form to edit the project
  };

  const handleDeleteProject = async (projectId: string) => {
    if (!confirm("Are you sure you want to delete this project?")) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-e4cfbb59/projects/${projectId}`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        setProjects(projects.filter((p) => p.id !== projectId));
      } else {
        const data = await response.json();
        alert(`Error: ${data.error}`);
      }
    } catch (err) {
      console.error("Delete project error:", err);
      alert("Failed to delete project");
    }
  };

  const handleEditHero = () => {
    alert("Edit Hero section");
  };

  const handleEditAbout = () => {
    alert("Edit About section");
  };

  const handleEditContact = () => {
    alert("Edit Contact section");
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Auth Modal */}
      {showAuth && (
        <Auth onClose={() => setShowAuth(false)} onAuthSuccess={handleAuthSuccess} />
      )}

      {/* Main Content */}
      <Header
        isAuthenticated={isAuthenticated}
        onLoginClick={() => setShowAuth(true)}
        onLogoutClick={handleSignOut}
      />
      <Hero isAdmin={isAuthenticated} onEdit={handleEditHero} />
      <Projects
        projects={projects}
        isAdmin={isAuthenticated}
        onAddProject={handleAddProject}
        onEditProject={handleEditProject}
        onDeleteProject={handleDeleteProject}
      />
      <About isAdmin={isAuthenticated} onEdit={handleEditAbout} />
      <Contact isAdmin={isAuthenticated} onEdit={handleEditContact} />
      <Footer />
    </div>
  );
}
